/*******************************************************************************
 * Copyright (c) 2009-2018 Weasis Team and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v20.html
 *
 * Contributors:
 *     Nicolas Roduit - initial API and implementation
 *******************************************************************************/
package org.weasis.core.api.gui.util;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicTreeUI;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

@SuppressWarnings("serial")
public class TreeSelection extends JTree {

    public void constructTree(DefaultTreeModel model) {
        this.setModel(model);
        this.setShowsRootHandles(true);
        this.setRootVisible(false);
        DefaultTreeCellRenderer renderer = new DefaultTreeCellRenderer();
        ImageIcon plus = new ImageIcon(getClass().getResource("/icon/plusTree.png")); //$NON-NLS-1$
        ImageIcon minus = new ImageIcon(getClass().getResource("/icon/minusTree.png")); //$NON-NLS-1$
        ComponentUI ui = this.getUI();
        if (ui instanceof BasicTreeUI) {
            ((BasicTreeUI) ui).setExpandedIcon(minus);
            ((BasicTreeUI) ui).setCollapsedIcon(plus);
        }
        renderer.setOpenIcon(null);
        renderer.setClosedIcon(null);
        renderer.setLeafIcon(null);
        this.setCellRenderer(renderer);
    }

    public DefaultMutableTreeNode getRoot() {
        return (DefaultMutableTreeNode) getModel().getRoot();
    }

    public TreePath getTreePath(DefaultMutableTreeNode node) {
        ResourceBundle.getBundle("javax.help.resources.Constants", Locale.getDefault()); //$NON-NLS-1$
        return new TreePath(((DefaultTreeModel) getModel()).getPathToRoot(node));
    }

}
